import { createBrowserRouter, Navigate } from 'react-router-dom';
import STSClearanceApp from '../sts-clearance-app';
import SettingsPage from './components/Pages/SettingsPage';
import ProfilePage from './components/Pages/ProfilePage';
import NotificationsPage from './components/Pages/NotificationsPage';
import HelpPage from './components/Pages/HelpPage';
import LoginPage from './components/Pages/LoginPage';
import RegisterPage from './components/Pages/RegisterPage';
import RegionalOperationsPage from './components/Pages/RegionalOperationsPage';
import SanctionsCheckerPage from './components/Pages/SanctionsCheckerPage';
import ApprovalMatrixPage from './components/Pages/ApprovalMatrixPage';
import { DashboardCustomizationPage } from './components/Pages/DashboardCustomizationPage';
import { AdvancedFilteringPage } from './components/Pages/AdvancedFilteringPage';
import { RolePermissionMatrixPage } from './components/Pages/RolePermissionMatrixPage';
import PerformanceDashboardPage from './components/Pages/PerformanceDashboardPage';
import { AdminDashboard } from './components/Pages/AdminDashboard';
import { RoleDashboardSelector } from './components/Pages/RoleDashboardSelector';
import { DashboardContainer } from './components/Pages/DashboardContainer'; // NEW: Unified dashboard
import RoomDetailPage from './components/Pages/RoomDetailPage';
import UserManagementPage from './components/Pages/UserManagementPage';
import VesselManagementPage from './components/Pages/VesselManagementPage';
import { ProtectedRoute } from './components/ProtectedRoute';

export const router = createBrowserRouter([
  {
    path: '/login',
    element: <LoginPage />
  },
  {
    path: '/register',
    element: <RegisterPage />
  },
  {
    path: '/',
    element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>,
    children: [
      {
        index: true,
        element: <Navigate to="/overview" replace />
      },
      {
        path: 'dashboard',
        element: <ProtectedRoute><DashboardContainer /></ProtectedRoute> // PHASE 0: Unified dashboard (replaces RoleDashboardSelector)
      },
      {
        path: 'rooms/:roomId',
        element: <ProtectedRoute><RoomDetailPage /></ProtectedRoute>
      },
      {
        path: 'users',
        element: <ProtectedRoute><UserManagementPage /></ProtectedRoute>
      },
      {
        path: 'vessels',
        element: <ProtectedRoute><VesselManagementPage /></ProtectedRoute>
      },
      {
        path: 'overview',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'documents',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'missing',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'approval',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'activity',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'history',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'messages',
        element: <ProtectedRoute><STSClearanceApp /></ProtectedRoute>
      },
      {
        path: 'settings',
        element: <ProtectedRoute><SettingsPage /></ProtectedRoute>
      },
      {
        path: 'profile',
        element: <ProtectedRoute><ProfilePage /></ProtectedRoute>
      },
      {
        path: 'notifications',
        element: <ProtectedRoute><NotificationsPage /></ProtectedRoute>
      },
      {
        path: 'help',
        element: <ProtectedRoute><HelpPage /></ProtectedRoute>
      },
      {
        path: 'regional-operations',
        element: <ProtectedRoute><RegionalOperationsPage /></ProtectedRoute>
      },
      {
        path: 'sanctions-checker',
        element: <ProtectedRoute><SanctionsCheckerPage /></ProtectedRoute>
      },
      {
        path: 'approval-matrix',
        element: <ProtectedRoute><ApprovalMatrixPage /></ProtectedRoute>
      },
      {
        path: 'dashboard-customization',
        element: <ProtectedRoute><DashboardCustomizationPage /></ProtectedRoute>
      },
      {
        path: 'advanced-filtering',
        element: <ProtectedRoute><AdvancedFilteringPage /></ProtectedRoute>
      },
      {
        path: 'role-permission-matrix',
        element: <ProtectedRoute><RolePermissionMatrixPage /></ProtectedRoute>
      },
      {
        path: 'performance-dashboard',
        element: <ProtectedRoute><PerformanceDashboardPage /></ProtectedRoute>
      },
      {
        path: 'admin-dashboard',
        element: <ProtectedRoute><AdminDashboard /></ProtectedRoute>
      }
    ]
  }
]);
