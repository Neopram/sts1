// This file has been moved to src/pages/RegionalOperationsPage.tsx
// This file is kept here temporarily to avoid breaking any old imports
export { default } from '../../pages/RegionalOperationsPage';