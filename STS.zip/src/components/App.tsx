// This file is not used - the main app component is in sts-clearance-app.tsx
// Keeping this file to avoid import errors

import React from 'react';

const App: React.FC = () => {
  return <div>This component is not used</div>;
};

export default App;