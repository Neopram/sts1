"""
Routers package for STS Clearance Hub
Contains all API route handlers
"""
